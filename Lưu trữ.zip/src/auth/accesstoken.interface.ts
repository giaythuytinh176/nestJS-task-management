export interface AccessTokenInterface {
  accessToken: string;
}

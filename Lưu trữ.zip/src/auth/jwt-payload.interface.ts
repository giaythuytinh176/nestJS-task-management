export interface JwtPayloadInterface {
  username: string;
  user_id: number;
}
